
<!-- Site echo permet d'insérer  l'URL-->
<div class="slide">
	<div class="title">
		<div>
			<h1>Soutien scolaire <br/> à domicile</h1>
		    <a href="#">Plus d'informations</a>
		</div>
		
	</div>
</div>