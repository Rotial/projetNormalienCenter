<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title><?php if(isset($title)){echo ($title) ;} ?></title>
	<link rel="preconnect" href="https://fonts.googleapis.com">
 	<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
	<link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,500;0,700;1,400&display=swap" rel="stylesheet"> 
	<link rel="stylesheet" type="text/css" href="<?php echo base_url();  ?>assets/css/style.css">
	
</head>
<body>
	<header>
		<div class="top-nav">
			<div class="logo" > <a href="#">Normalien Center </a> </div>
		<nav>
			<ul> 

				<li>
					<a href="#">Home</a>
				</li>


				<li>
					<a href="#">Soutien scolaire</a>
				</li>

				<li>
					<a href="#">Cours particulier</a>
				</li>

				<li>
					<a href="#">Recrutement</a>
				</li>

			</ul>
		</nav>

		<div class="nav-right"><a href="<?php echo base_url().'app/register' ?>">S'inscrire</a></div>
		</div>

	</header>


